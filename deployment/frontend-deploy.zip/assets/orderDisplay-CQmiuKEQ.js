const e=t=>!t||["standard plant pot","available","default"].includes(t.trim().toLowerCase()),r=t=>{const a=Number(t);return Number.isFinite(a)?a.toLocaleString():"-"};export{r as f,e as i};
